import { json, readJson } from '../../_lib/http.js';
import { requireUser } from '../../_lib/auth.js';
import { cleanProfile } from '../../_lib/validate.js';
import { rateLimitUser } from '../../_lib/ratelimit.js';
import { loadProfile } from '../../_lib/profile.js';

// GET /api/profile → ملفي الشخصي
export async function onRequestGet({ request, env }) {
  const u = await requireUser(env, request);
  return json({ profile: await loadProfile(env.DB, u.id) });
}

// PUT /api/profile → حفظ الملف كاملًا (يُنظَّف ويُتحقق منه بالكامل في الخادم)
export async function onRequestPut({ request, env }) {
  const u = await requireUser(env, request);
  await rateLimitUser(env.DB, u.id, 'profile', 30, 60);
  const p = cleanProfile(await readJson(request, 16384));
  await env.DB.prepare(
    'UPDATE profiles SET name=?, type=?, field=?, loc=?, bio=?, whatsapp=?, socials=?, hours_from=?, hours_to=?, avatar=?, cover=?, cover_x=?, cover_y=?, updated_at=? WHERE user_id=?'
  ).bind(p.name, p.type, p.field, p.loc, p.bio, p.whatsapp, JSON.stringify(p.socials),
    p.hours ? p.hours.from : null, p.hours ? p.hours.to : null, p.avatar, p.cover, p.coverPos.x, p.coverPos.y, Date.now(), u.id).run();
  await env.DB.prepare('UPDATE users SET name = ?, avatar = ? WHERE id = ?').bind(p.name, p.avatar, u.id).run();
  return json({ profile: await loadProfile(env.DB, u.id) });
}
