import { json, fail, requireDb } from '../../_lib/http.js';
import { getUser } from '../../_lib/auth.js';
import { loadProfile } from '../../_lib/profile.js';

// GET /api/profile/<userId> → ملف عام (بدون بريد أو بيانات خاصة)
export async function onRequestGet({ request, env, params }) {
  const DB = requireDb(env);
  const id = String(params.id || '');
  if (!/^[0-9a-f-]{36}$/.test(id)) fail(404, 'not_found', 'غير موجود');
  const p = await loadProfile(DB, id);
  if (!p) fail(404, 'not_found', 'غير موجود');
  const me = await getUser(env, request);
  let following = false;
  if (me) following = !!(await DB.prepare('SELECT 1 AS x FROM follows WHERE follower_id = ? AND followee_id = ?').bind(me.id, id).first());
  return json({ profile: p, following });
}
