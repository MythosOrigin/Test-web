import { json, readJson } from '../../_lib/http.js';
import { requireUser } from '../../_lib/auth.js';

// POST /api/notifications/read  { ids?: [..] } → بدون ids = تعليم الكل كمقروء
export async function onRequestPost({ request, env }) {
  const u = await requireUser(env, request);
  const b = await readJson(request, 8192);
  if (Array.isArray(b.ids) && b.ids.length) {
    const ids = b.ids.filter(x => typeof x === 'string' && /^[0-9a-f]{16}$/.test(x)).slice(0, 100);
    if (ids.length) await env.DB.prepare(`UPDATE notifications SET read = 1 WHERE user_id = ? AND id IN (${ids.map(() => '?').join(',')})`).bind(u.id, ...ids).run();
  } else {
    await env.DB.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').bind(u.id).run();
  }
  return json({ ok: true });
}
