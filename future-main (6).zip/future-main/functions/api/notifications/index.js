import { json } from '../../_lib/http.js';
import { requireUser } from '../../_lib/auth.js';
import { NOTIFICATION_TYPES } from '../../_lib/validate.js';

// GET /api/notifications → [{ id, type, name, avatar, time, read }]  (نفس شكل الواجهة)
export async function onRequestGet({ request, env }) {
  const u = await requireUser(env, request);
  const rows = await env.DB.prepare(
    'SELECT n.id, n.type, n.read, n.created_at, COALESCE(NULLIF(p.name, \'\'), a.name, \'\') AS name, COALESCE(NULLIF(p.avatar, \'\'), a.avatar, \'\') AS avatar ' +
    'FROM notifications n LEFT JOIN users a ON a.id = n.actor_id LEFT JOIN profiles p ON p.user_id = n.actor_id ' +
    'WHERE n.user_id = ? ORDER BY n.created_at DESC LIMIT 50'
  ).bind(u.id).all();
  const items = (rows.results || []).filter(r => NOTIFICATION_TYPES.includes(r.type))
    .map(r => ({ id: r.id, type: r.type, name: r.name, avatar: r.avatar, time: r.created_at, read: !!r.read }));
  return json({ items, unread: items.filter(i => !i.read).length });
}
