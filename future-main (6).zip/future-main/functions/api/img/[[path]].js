import { fail } from '../../_lib/http.js';
import { IMG_KEY } from '../../_lib/validate.js';

// GET /api/img/u/<user>/<name>.jpg → يقدّم الصورة من R2 (الأسماء عشوائية وثابتة فيُخزَّن الرد طويلًا)
export async function onRequestGet({ env, params }) {
  if (!env.UPLOADS) fail(404, 'not_found', 'غير موجود');
  const key = Array.isArray(params.path) ? params.path.join('/') : String(params.path || '');
  if (!IMG_KEY.test(key)) fail(404, 'not_found', 'غير موجود');
  const obj = await env.UPLOADS.get(key);
  if (!obj) fail(404, 'not_found', 'غير موجود');
  return new Response(obj.body, {
    headers: {
      'Content-Type': (obj.httpMetadata && obj.httpMetadata.contentType) || 'application/octet-stream',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; sandbox",
      'Cross-Origin-Resource-Policy': 'same-origin',
    },
  });
}
