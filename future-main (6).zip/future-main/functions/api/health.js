import { json } from '../_lib/http.js';

// افتح /api/health للتأكد من أن الربط سليم
export async function onRequestGet({ env }) {
  let db = false;
  try { if (env.DB) { await env.DB.prepare('SELECT 1').first(); db = true; } } catch (e) { db = false; }
  const gid = env.GOOGLE_CLIENT_ID || '';
  return json({
    ok: true,
    db,
    migrated: db ? await hasTable(env.DB, 'users') : false,
    uploads: !!env.UPLOADS,
    googleLogin: !!gid && !gid.startsWith('REPLACE'),
    time: new Date().toISOString(),
  });
}
async function hasTable(DB, name) {
  try { return !!(await DB.prepare("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?").bind(name).first()); }
  catch (e) { return false; }
}
