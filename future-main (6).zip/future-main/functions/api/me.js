import { json, readJson, fail, requireDb } from '../_lib/http.js';
import { getUser, requireUser, clearCookie } from '../_lib/auth.js';

// GET /api/me → المستخدم الحالي أو null (لا يرجع 401 حتى لا يزعج الواجهة)
export async function onRequestGet({ request, env }) {
  if (!env.DB) return json({ user: null });
  const u = await getUser(env, request);
  return json({ user: u ? { id: u.id, name: u.name, avatar: u.avatar, role: u.role } : null });
}

// DELETE /api/me  { confirm: true } → حذف الحساب وكل بياناته نهائيًا
export async function onRequestDelete({ request, env }) {
  const DB = requireDb(env);
  const u = await requireUser(env, request);
  const body = await readJson(request, 1024);
  if (body.confirm !== true) fail(400, 'confirm_required', 'يلزم تأكيد الحذف');
  if (env.UPLOADS) {
    const rows = await DB.prepare('SELECT key FROM uploads WHERE user_id = ?').bind(u.id).all();
    const keys = (rows.results || []).map(r => r.key);
    for (let i = 0; i < keys.length; i += 100) await env.UPLOADS.delete(keys.slice(i, i + 100));
  }
  await DB.prepare('DELETE FROM users WHERE id = ?').bind(u.id).run();   // الباقي يُحذف تلقائيًا (CASCADE)
  return json({ ok: true }, 200, { 'Set-Cookie': clearCookie() });
}
