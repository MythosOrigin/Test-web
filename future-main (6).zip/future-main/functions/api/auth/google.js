import { json, readJson, fail, requireDb, randomHex } from '../../_lib/http.js';
import { verifyGoogleIdToken } from '../../_lib/google.js';
import { createSession, sessionCookie } from '../../_lib/auth.js';
import { rateLimitIp, cleanupRateLimits } from '../../_lib/ratelimit.js';
import { cleanText } from '../../_lib/validate.js';

// POST /api/auth/google  { credential: "<Google ID token>" }
export async function onRequestPost({ request, env }) {
  const DB = requireDb(env);
  const clientId = env.GOOGLE_CLIENT_ID || '';
  if (!clientId || clientId.startsWith('REPLACE')) fail(503, 'not_configured', 'تسجيل الدخول بـ Google غير مفعّل بعد');
  await rateLimitIp(DB, request, 'auth', 10, 60);

  const body = await readJson(request, 8192);
  const cred = body.credential;
  if (typeof cred !== 'string' || cred.length < 100 || cred.length > 4096) fail(400, 'bad_credential', 'بيانات الدخول غير صالحة');

  let claims;
  try { claims = await verifyGoogleIdToken(cred, clientId); }
  catch (e) { console.warn('google verify failed:', e && e.message); fail(401, 'invalid_token', 'تعذّر التحقق من حساب Google'); }

  const email = String(claims.email).toLowerCase();
  const admins = String(env.ADMIN_EMAILS || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
  const isAdmin = admins.includes(email);
  const now = Date.now();
  const name = cleanText(claims.name || '', 35);
  const avatar = typeof claims.picture === 'string' && /^https:\/\/lh3\.googleusercontent\.com\//.test(claims.picture) ? claims.picture.slice(0, 500) : '';

  let user = await DB.prepare('SELECT id, status, role FROM users WHERE google_sub = ?').bind(claims.sub).first();
  if (user && user.status !== 'active') fail(403, 'banned', 'هذا الحساب موقوف');

  if (!user) {
    const id = crypto.randomUUID();
    await DB.batch([
      DB.prepare('INSERT INTO users(id,google_sub,email,name,avatar,role,status,created_at,last_login_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .bind(id, claims.sub, email, name, avatar, isAdmin ? 'admin' : 'user', 'active', now, now),
      DB.prepare('INSERT INTO profiles(user_id,name,avatar,updated_at) VALUES(?,?,?,?)').bind(id, name, avatar, now),
    ]);
    user = { id, role: isAdmin ? 'admin' : 'user' };
  } else {
    await DB.prepare('UPDATE users SET email = ?, last_login_at = ?, role = CASE WHEN ? = 1 THEN \'admin\' ELSE role END WHERE id = ?')
      .bind(email, now, isAdmin ? 1 : 0, user.id).run();
    if (isAdmin) user.role = 'admin';
  }

  const token = await createSession(DB, user.id, request);
  if (randomHex(1) < '10') await cleanupRateLimits(DB);   // تنظيف دوري خفيف

  const prof = await DB.prepare('SELECT name, avatar FROM profiles WHERE user_id = ?').bind(user.id).first();
  return json({ user: { id: user.id, name: (prof && prof.name) || name, avatar: (prof && prof.avatar) || avatar, role: user.role } }, 200, { 'Set-Cookie': sessionCookie(token) });
}
