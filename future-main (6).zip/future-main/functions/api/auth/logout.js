import { json } from '../../_lib/http.js';
import { getUser, clearCookie } from '../../_lib/auth.js';

export async function onRequestPost({ request, env }) {
  const u = await getUser(env, request);
  if (u) await env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(u.sessionId).run();
  return json({ ok: true }, 200, { 'Set-Cookie': clearCookie() });
}
