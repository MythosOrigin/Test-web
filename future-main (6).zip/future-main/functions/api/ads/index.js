import { json, readJson, fail, requireDb, randomHex } from '../../_lib/http.js';
import { requireUser } from '../../_lib/auth.js';
import { cleanText, escapeLike, IMG_KEY } from '../../_lib/validate.js';
import { rateLimitUser } from '../../_lib/ratelimit.js';
import { adRow, AD_SELECT, joinPath } from '../../_lib/ads.js';

// GET /api/ads?p=الإعلانات&p=سيارات&limit=20&cursor=...&user=<id>
export async function onRequestGet({ request, env }) {
  const DB = requireDb(env);
  const url = new URL(request.url);
  const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get('limit') || '20', 10) || 20));
  const where = ["a.status = 'active'", "u.status = 'active'"]; const args = [];

  const p = url.searchParams.getAll('p').slice(0, 8).map(s => cleanText(s, 60)).filter(Boolean);
  if (p.length) {
    const prefix = joinPath(p);
    where.push("(a.path_text = ? OR a.path_text LIKE ? ESCAPE '\\')");
    args.push(prefix, escapeLike(prefix) + '\u001f%');
  }
  const userId = url.searchParams.get('user');
  if (userId) { if (!/^[0-9a-f-]{36}$/.test(userId)) fail(400, 'bad_user', 'معرّف غير صالح'); where.push('a.user_id = ?'); args.push(userId); }

  const cursor = url.searchParams.get('cursor');
  if (cursor) {
    const m = /^(\d{10,15})\.([0-9a-f]{16})$/.exec(cursor);
    if (!m) fail(400, 'bad_cursor', 'مؤشر غير صالح');
    where.push('(a.created_at < ? OR (a.created_at = ? AND a.id < ?))'); args.push(+m[1], +m[1], m[2]);
  }
  const rows = await DB.prepare(AD_SELECT + 'WHERE ' + where.join(' AND ') + ' ORDER BY a.created_at DESC, a.id DESC LIMIT ?')
    .bind(...args, limit + 1).all();
  const list = rows.results || [];
  const more = list.length > limit; if (more) list.pop();
  const last = list[list.length - 1];
  return json({ items: list.map(r => adRow(r)), next: more && last ? `${last.created_at}.${last.id}` : null });
}

// POST /api/ads  { path:[..], title, description, price|null, currency, images:[key,..] }
export async function onRequestPost({ request, env }) {
  const DB = requireDb(env);
  const u = await requireUser(env, request);
  await rateLimitUser(DB, u.id, 'ad', 20, 86400);
  const b = await readJson(request, 16384);

  const path = Array.isArray(b.path) ? b.path.slice(0, 8).map(s => cleanText(s, 60).replace(/\u001f/g, '')).filter(Boolean) : [];
  if (!path.length) fail(400, 'bad_path', 'اختر تصنيف الإعلان');
  const title = cleanText(b.title, 120);
  if (!title) fail(400, 'bad_title', 'يرجى كتابة عنوان للإعلان');
  const description = cleanText(b.description, 2000, true);

  let price = null;
  if (b.price !== null && b.price !== undefined) {
    price = Number(b.price);
    if (!Number.isFinite(price) || price < 1 || price > 30000000) fail(400, 'bad_price', 'يرجى إدخال سعر صحيح');
  }
  const currency = cleanText(b.currency, 8);

  const keys = Array.isArray(b.images) ? [...new Set(b.images.filter(k => typeof k === 'string' && IMG_KEY.test(k)))].slice(0, 10) : [];
  if (keys.length) {   // الصور يجب أن تكون مرفوعة بواسطة نفس المستخدم
    const ph = keys.map(() => '?').join(',');
    const own = await DB.prepare(`SELECT key FROM uploads WHERE user_id = ? AND key IN (${ph})`).bind(u.id, ...keys).all();
    if ((own.results || []).length !== keys.length) fail(400, 'bad_images', 'صور غير صالحة');
  }

  const now = Date.now(); const id = randomHex(8);
  await DB.prepare('INSERT INTO ads(id,user_id,root,path,path_text,title,description,price,currency,images,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(id, u.id, path[0], JSON.stringify(path), joinPath(path), title, description, price, currency, JSON.stringify(keys), 'active', now, now).run();
  const row = await DB.prepare(AD_SELECT + 'WHERE a.id = ?').bind(id).first();
  return json({ ad: adRow(row, true) }, 201);
}
