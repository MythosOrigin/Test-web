import { json, fail, requireDb } from '../../_lib/http.js';
import { requireUser } from '../../_lib/auth.js';
import { adRow, AD_SELECT } from '../../_lib/ads.js';

const okId = (id) => /^[0-9a-f]{16}$/.test(id);

export async function onRequestGet({ env, params }) {
  const DB = requireDb(env);
  if (!okId(params.id)) fail(404, 'not_found', 'غير موجود');
  const r = await DB.prepare(AD_SELECT + "WHERE a.id = ? AND a.status = 'active' AND u.status = 'active'").bind(params.id).first();
  if (!r) fail(404, 'not_found', 'غير موجود');
  return json({ ad: adRow(r, true) });
}

// DELETE: صاحب الإعلان أو المشرف/المدير (حذف ناعم يمكن استرجاعه من قاعدة البيانات)
export async function onRequestDelete({ request, env, params }) {
  const DB = requireDb(env);
  const u = await requireUser(env, request);
  if (!okId(params.id)) fail(404, 'not_found', 'غير موجود');
  const r = await DB.prepare("SELECT user_id FROM ads WHERE id = ? AND status = 'active'").bind(params.id).first();
  if (!r) fail(404, 'not_found', 'غير موجود');
  if (r.user_id !== u.id && u.role !== 'admin' && u.role !== 'mod') fail(403, 'forbidden', 'غير مصرّح لك بهذا الإجراء');
  await DB.prepare("UPDATE ads SET status = 'removed', updated_at = ? WHERE id = ?").bind(Date.now(), params.id).run();
  return json({ ok: true });
}
