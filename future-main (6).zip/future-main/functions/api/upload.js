import { json, fail, requireDb, randomHex } from '../_lib/http.js';
import { requireUser } from '../_lib/auth.js';
import { rateLimitUser } from '../_lib/ratelimit.js';

const MAX = 5 * 1024 * 1024;
const TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

// نتحقق من البايتات الفعلية للملف (لا نثق بالامتداد ولا بالنوع المُعلن)
function sniff(b) {
  if (b.length > 12 && b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) return 'image/jpeg';
  if (b.length > 12 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47 && b[4] === 0x0D && b[5] === 0x0A && b[6] === 0x1A && b[7] === 0x0A) return 'image/png';
  if (b.length > 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'image/webp';
  return '';
}

// POST /api/upload   Content-Type: image/jpeg|png|webp   Body: ملف الصورة الخام
export async function onRequestPost({ request, env }) {
  const DB = requireDb(env);
  if (!env.UPLOADS) fail(503, 'not_configured', 'رفع الصور غير مفعّل بعد');
  const u = await requireUser(env, request);
  await rateLimitUser(DB, u.id, 'upload', 40, 86400);

  const declared = (request.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!TYPES[declared]) fail(415, 'bad_type', 'الصيغ المسموحة: JPG وPNG وWebP');
  if (Number(request.headers.get('content-length') || 0) > MAX) fail(413, 'too_large', 'الصورة كبيرة (الحد 5 ميجا)');
  const buf = new Uint8Array(await request.arrayBuffer());
  if (buf.length === 0 || buf.length > MAX) fail(413, 'too_large', 'الصورة كبيرة (الحد 5 ميجا)');
  if (sniff(buf) !== declared) fail(415, 'bad_image', 'الملف ليس صورة صالحة');

  const key = `u/${u.id}/${randomHex(12)}.${TYPES[declared]}`;
  await env.UPLOADS.put(key, buf, { httpMetadata: { contentType: declared } });
  await DB.prepare('INSERT INTO uploads(key,user_id,content_type,size,created_at) VALUES(?,?,?,?,?)').bind(key, u.id, declared, buf.length, Date.now()).run();
  return json({ key, url: '/api/img/' + key }, 201);
}
