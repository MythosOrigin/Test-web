import { json, fail, requireDb } from '../../_lib/http.js';
import { requireUser } from '../../_lib/auth.js';
import { rateLimitUser } from '../../_lib/ratelimit.js';

// المتابعة لا تُنتج إشعارات (الإشعارات فقط: تعليق/تفاعل على الرحلات)
async function target(DB, me, id) {
  if (!/^[0-9a-f-]{36}$/.test(id)) fail(404, 'not_found', 'غير موجود');
  if (id === me.id) fail(400, 'self_follow', 'لا يمكنك متابعة نفسك');
  const t = await DB.prepare("SELECT id FROM users WHERE id = ? AND status = 'active'").bind(id).first();
  if (!t) fail(404, 'not_found', 'غير موجود');
}
const count = async (DB, id) => (await DB.prepare('SELECT COUNT(*) AS n FROM follows WHERE followee_id = ?').bind(id).first()).n;

export async function onRequestPost({ request, env, params }) {
  const DB = requireDb(env);
  const me = await requireUser(env, request);
  await rateLimitUser(DB, me.id, 'follow', 60, 60);
  await target(DB, me, params.id);
  await DB.prepare('INSERT OR IGNORE INTO follows(follower_id, followee_id, created_at) VALUES(?,?,?)').bind(me.id, params.id, Date.now()).run();
  return json({ following: true, followers: await count(DB, params.id) });
}

export async function onRequestDelete({ request, env, params }) {
  const DB = requireDb(env);
  const me = await requireUser(env, request);
  await rateLimitUser(DB, me.id, 'follow', 60, 60);
  await target(DB, me, params.id);
  await DB.prepare('DELETE FROM follows WHERE follower_id = ? AND followee_id = ?').bind(me.id, params.id).run();
  return json({ following: false, followers: await count(DB, params.id) });
}
