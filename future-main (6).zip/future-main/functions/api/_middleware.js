import { json, HttpError, fail } from '../_lib/http.js';

// يمرّ عليه كل طلب إلى /api/*: حماية CSRF (تطابق Origin) + معالجة أخطاء موحّدة.
// لا نضيف ترويسات CORS عمدًا: الـ API لا يُستدعى إلا من موقعك نفسه.
export async function onRequest(context) {
  const { request } = context;
  try {
    const m = request.method;
    if (m === 'OPTIONS') return new Response(null, { status: 204, headers: { 'Cache-Control': 'no-store' } });
    if (m !== 'GET' && m !== 'HEAD') {
      if (request.headers.get('Origin') !== new URL(request.url).origin) fail(403, 'bad_origin', 'طلب مرفوض');
    }
    return await context.next();
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.code, message: e.userMessage }, e.status);
    console.error('API error:', e && e.stack || e);
    return json({ error: 'server_error', message: 'حدث خطأ غير متوقع' }, 500);
  }
}
