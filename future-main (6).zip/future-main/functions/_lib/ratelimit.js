import { clientIp, sha256Hex, fail } from './http.js';

// حد طلبات بنافذة ثابتة داخل D1. المفتاح = النطاق + (IP مُجزّأ أو معرّف مستخدم)
export async function rateLimit(DB, key, limit, windowSec) {
  const now = Date.now();
  const w = Math.floor(now / (windowSec * 1000));
  const row = await DB.prepare(
    'INSERT INTO rate_limits(key, window, count, updated_at) VALUES(?1, ?2, 1, ?3) ' +
    'ON CONFLICT(key) DO UPDATE SET count = CASE WHEN window = excluded.window THEN count + 1 ELSE 1 END, ' +
    'window = excluded.window, updated_at = excluded.updated_at RETURNING count'
  ).bind(key, w, now).first();
  if (row && row.count > limit) fail(429, 'rate_limited', 'محاولات كثيرة، حاول مجددًا بعد قليل');
}
export async function rateLimitIp(DB, request, scope, limit, windowSec) {
  const h = (await sha256Hex(clientIp(request))).slice(0, 24);
  return rateLimit(DB, scope + ':ip:' + h, limit, windowSec);
}
export function rateLimitUser(DB, userId, scope, limit, windowSec) {
  return rateLimit(DB, scope + ':u:' + userId, limit, windowSec);
}
export async function cleanupRateLimits(DB) {
  await DB.prepare('DELETE FROM rate_limits WHERE updated_at < ?').bind(Date.now() - 2 * 86400000).run();
}
