// تحويل صف الملف الشخصي إلى الشكل الذي تتوقعه الواجهة (نفس حقول emptyProfile في app.js)
export async function loadProfile(DB, userId) {
  const r = await DB.prepare(
    'SELECT p.*, (SELECT COUNT(*) FROM follows f WHERE f.followee_id = p.user_id) AS followers FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.user_id = ? AND u.status = \'active\''
  ).bind(userId).first();
  if (!r) return null;
  let socials = []; try { socials = JSON.parse(r.socials); } catch (e) {}
  return {
    id: r.user_id, name: r.name, type: r.type, field: r.field, followers: r.followers || 0, loc: r.loc,
    socials, whatsapp: r.whatsapp, bio: r.bio,
    hours: r.hours_from && r.hours_to ? { from: r.hours_from, to: r.hours_to } : null,
    avatar: r.avatar, cover: r.cover, coverPos: { x: r.cover_x, y: r.cover_y },
  };
}
