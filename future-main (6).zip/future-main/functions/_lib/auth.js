import { fail, sha256Hex, randomToken, requireDb } from './http.js';

export const COOKIE = '__Host-lion_sid';
const TTL = 30 * 86400000;      // مدة الجلسة 30 يومًا
const TOUCH = 3600000;          // تجديد الجلسة كل ساعة عند النشاط
const MAX_SESSIONS = 10;

export function readCookie(request, name) {
  const h = request.headers.get('Cookie') || '';
  for (const part of h.split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return '';
}
export const sessionCookie = (token) => `${COOKIE}=${token}; Path=/; Max-Age=${TTL / 1000}; HttpOnly; Secure; SameSite=Lax`;
export const clearCookie = () => `${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`;

export async function createSession(DB, userId, request) {
  const token = randomToken(32);
  const id = await sha256Hex(token);               // نخزّن البصمة فقط، لا الرمز نفسه
  const now = Date.now();
  await DB.prepare('INSERT INTO sessions(id,user_id,created_at,last_seen_at,expires_at,user_agent) VALUES(?,?,?,?,?,?)')
    .bind(id, userId, now, now, now + TTL, (request.headers.get('User-Agent') || '').slice(0, 200)).run();
  await DB.prepare('DELETE FROM sessions WHERE user_id = ?1 AND id NOT IN (SELECT id FROM sessions WHERE user_id = ?1 ORDER BY last_seen_at DESC LIMIT ?2)')
    .bind(userId, MAX_SESSIONS).run();
  await DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now).run();
  return token;
}

export async function getUser(env, request) {
  const token = readCookie(request, COOKIE);
  if (!/^[A-Za-z0-9_-]{43}$/.test(token) || !env.DB) return null;
  const id = await sha256Hex(token);
  const now = Date.now();
  const row = await env.DB.prepare(
    'SELECT u.id, u.name, u.avatar, u.role, u.status, s.last_seen_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ? AND s.expires_at > ?'
  ).bind(id, now).first();
  if (!row || row.status !== 'active') return null;
  if (now - row.last_seen_at > TOUCH) {
    await env.DB.prepare('UPDATE sessions SET last_seen_at = ?, expires_at = ? WHERE id = ?').bind(now, now + TTL, id).run();
  }
  return { id: row.id, name: row.name, avatar: row.avatar, role: row.role, sessionId: id };
}

export async function requireUser(env, request) {
  requireDb(env);
  const u = await getUser(env, request);
  if (!u) fail(401, 'unauthorized', 'سجّل دخولك أولاً');
  return u;
}
export function requireRole(user, roles) {
  if (!roles.includes(user.role)) fail(403, 'forbidden', 'غير مصرّح لك بهذا الإجراء');
}
