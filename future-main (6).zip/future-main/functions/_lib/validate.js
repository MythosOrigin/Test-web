// تنظيف المدخلات والتحقق منها (الخادم لا يثق بأي شيء قادم من المتصفح)
const STRIP_SINGLE = /[\u0000-\u001F\u007F\u200B\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
const STRIP_MULTI = /[\u0000-\u0009\u000B\u000C\u000E-\u001F\u007F\u200B\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;

export function cleanText(v, max, multiline = false) {
  if (typeof v !== 'string') return '';
  let s = v.normalize('NFC');
  if (multiline) {
    s = s.replace(/\r\n?/g, '\n').replace(STRIP_MULTI, '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n');
  } else {
    s = s.replace(STRIP_SINGLE, '').replace(/\s+/g, ' ');
  }
  return Array.from(s.trim()).slice(0, max).join('');
}

export const PROFILE_TYPES = ['store', 'advertiser', 'blender'];
export const SOCIAL_PLATFORMS = ['facebook', 'instagram', 'tiktok', 'youtube'];
// أنواع الإشعارات المسموحة: تعليق على رحلتك + تفاعل على رحلتك فقط
export const NOTIFICATION_TYPES = ['trip_comment', 'trip_reaction'];

const IMG_URL = /^\/api\/img\/u\/[0-9a-f-]{36}\/[0-9a-f]{24}\.(jpg|png|webp)$/;
const GOOGLE_AVATAR = /^https:\/\/lh3\.googleusercontent\.com\/[A-Za-z0-9_\-\/=.]{1,400}$/;
export function cleanImageUrl(v) {
  if (typeof v !== 'string') return '';
  return (IMG_URL.test(v) || GOOGLE_AVATAR.test(v)) ? v : '';
}
export const IMG_KEY = /^u\/[0-9a-f-]{36}\/[0-9a-f]{24}\.(jpg|png|webp)$/;

export function cleanProfile(d) {
  const o = (d && typeof d === 'object') ? d : {};
  const p = {
    name: cleanText(o.name, 35), type: PROFILE_TYPES.includes(o.type) ? o.type : '',
    field: cleanText(o.field, 30), loc: cleanText(o.loc, 30), bio: cleanText(o.bio, 250, true),
    whatsapp: '', socials: [], hours: null, avatar: cleanImageUrl(o.avatar), cover: cleanImageUrl(o.cover),
    coverPos: { x: 50, y: 50 },
  };
  if (typeof o.whatsapp === 'string') {
    const digits = o.whatsapp.replace(/[^\d]/g, '');
    if (digits.length >= 6 && digits.length <= 15) p.whatsapp = digits;
  }
  if (Array.isArray(o.socials)) {
    for (const s of o.socials.slice(0, 2)) {
      if (!s || !SOCIAL_PLATFORMS.includes(s.platform) || typeof s.value !== 'string') continue;
      const v = s.value.trim().replace(/^@/, '');
      if (/^[A-Za-z0-9._\-]{1,64}$/.test(v)) p.socials.push({ platform: s.platform, value: v });
    }
  }
  const t = /^([01]\d|2[0-3]):[0-5]\d$/;
  if (o.hours && t.test(o.hours.from) && t.test(o.hours.to)) p.hours = { from: o.hours.from, to: o.hours.to };
  if (o.coverPos && Number.isFinite(+o.coverPos.x) && Number.isFinite(+o.coverPos.y)) {
    p.coverPos = { x: Math.min(100, Math.max(0, +o.coverPos.x)), y: Math.min(100, Math.max(0, +o.coverPos.y)) };
  }
  return p;
}

export function escapeLike(s) { return s.replace(/[\\%_]/g, m => '\\' + m); }
export const PATH_SEP = '\u001f';
