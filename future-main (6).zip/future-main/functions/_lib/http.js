// أدوات HTTP مشتركة: ردود JSON آمنة، قراءة الجسم بحدود، أخطاء موحّدة
export const BASE_HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
};

export class HttpError extends Error {
  constructor(status, code, userMessage) {
    super(code);
    this.status = status;
    this.code = code;
    this.userMessage = userMessage || '';
  }
}
export function fail(status, code, userMessage) { throw new HttpError(status, code, userMessage); }

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...BASE_HEADERS, ...headers } });
}

export async function readJson(request, maxBytes = 65536) {
  const ct = (request.headers.get('content-type') || '').toLowerCase();
  if (!ct.includes('application/json')) fail(415, 'bad_content_type', 'نوع المحتوى غير مدعوم');
  const len = Number(request.headers.get('content-length') || 0);
  if (len > maxBytes) fail(413, 'too_large', 'الطلب كبير جدًا');
  const text = await request.text();
  if (text.length > maxBytes) fail(413, 'too_large', 'الطلب كبير جدًا');
  let data;
  try { data = JSON.parse(text); } catch (e) { fail(400, 'bad_json', 'بيانات غير صالحة'); }
  if (!data || typeof data !== 'object' || Array.isArray(data)) fail(400, 'bad_json', 'بيانات غير صالحة');
  return data;
}

export function clientIp(request) { return request.headers.get('CF-Connecting-IP') || '0.0.0.0'; }

export async function sha256Hex(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}
export function randomHex(bytes = 8) {
  const a = crypto.getRandomValues(new Uint8Array(bytes));
  return [...a].map(b => b.toString(16).padStart(2, '0')).join('');
}
export function randomToken(bytes = 32) {
  const a = crypto.getRandomValues(new Uint8Array(bytes));
  let s = ''; for (const b of a) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function requireDb(env) {
  if (!env.DB) fail(503, 'not_configured', 'الخادم غير مهيّأ بعد');
  return env.DB;
}
