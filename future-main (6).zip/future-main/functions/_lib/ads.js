import { PATH_SEP } from './validate.js';

export function adRow(r, full = false) {
  let images = []; try { images = JSON.parse(r.images).map(k => '/api/img/' + k); } catch (e) {}
  let path = []; try { path = JSON.parse(r.path); } catch (e) {}
  return {
    id: r.id, path, title: r.title,
    description: full ? r.description : r.description.slice(0, 200),
    price: r.price, currency: r.currency, images, createdAt: r.created_at,
    seller: { id: r.user_id, name: r.seller_name || '', avatar: r.seller_avatar || '' },
  };
}
export const AD_SELECT =
  'SELECT a.*, COALESCE(NULLIF(p.name, \'\'), u.name) AS seller_name, COALESCE(NULLIF(p.avatar, \'\'), u.avatar) AS seller_avatar ' +
  'FROM ads a JOIN users u ON u.id = a.user_id LEFT JOIN profiles p ON p.user_id = a.user_id ';
export const joinPath = (arr) => arr.join(PATH_SEP);
