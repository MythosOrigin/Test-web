// التحقق من Google ID Token بالتوقيع (RS256) دون أي مكتبات خارجية
const CERTS_URL = 'https://www.googleapis.com/oauth2/v3/certs';

function b64uToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
  const bin = atob(s); const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function b64uToJson(s) { return JSON.parse(new TextDecoder().decode(b64uToBytes(s))); }

export async function verifyGoogleIdToken(idToken, clientId) {
  const parts = String(idToken).split('.');
  if (parts.length !== 3) throw new Error('malformed');
  const header = b64uToJson(parts[0]);
  const claims = b64uToJson(parts[1]);
  if (header.alg !== 'RS256' || !header.kid) throw new Error('bad_alg');

  const res = await fetch(CERTS_URL, { cf: { cacheTtl: 3600, cacheEverything: true } });
  if (!res.ok) throw new Error('certs_unavailable');
  const jwk = (await res.json()).keys.find(k => k.kid === header.kid);
  if (!jwk) throw new Error('unknown_kid');

  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64uToBytes(parts[2]), new TextEncoder().encode(parts[0] + '.' + parts[1]));
  if (!ok) throw new Error('bad_signature');

  const now = Math.floor(Date.now() / 1000);
  if (claims.iss !== 'https://accounts.google.com' && claims.iss !== 'accounts.google.com') throw new Error('bad_iss');
  if (claims.aud !== clientId) throw new Error('bad_aud');
  if (typeof claims.exp !== 'number' || claims.exp < now - 60) throw new Error('expired');
  if (typeof claims.iat === 'number' && claims.iat > now + 300) throw new Error('bad_iat');
  if (!claims.sub || claims.email_verified !== true || !claims.email) throw new Error('unverified');
  return claims;
}
