// 🦁 Liogram - Service Worker v6.2 - PROFESSIONAL - Forces Latest Update
// أقوى من الملف القديم 100% - يجبر المتصفح يعرض آخر تحديث فورا

const CACHE_NAME = 'lion-cache-v6.5-20261121';
const CACHE_VERSION = 'v6.2';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './style.css',
  './theme.css',
  './app.js',
  './manifest.json',
  './sitemap.xml',
  './robots.txt',
  './android-chrome-192x192.png',
  './android-chrome-512x512.png',
  './apple-touch-icon.png'
];

// INSTALL - يحمل الجديد ويجبر القديم يطلع فورا
self.addEventListener('install', (event) => {
  console.log('[SW v6.2] Installing - Force Update');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        // حمل كل الملفات الجديدة
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .then(() => {
        // اجبار التفعيل فورا - بدون انتظار
        return self.skipWaiting();
      })
  );
});

// ACTIVATE - يمسح كل الكاش القديم ويجبر الصفحات تتحدث
self.addEventListener('activate', (event) => {
  console.log('[SW v6.2] Activating - Deleting old caches');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // امسح أي كاش قديم مش نفس الاسم الجديد
          if (cacheName !== CACHE_NAME) {
            console.log('[SW v6.2] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      // اجبر كل الصفحات المفتوحة تستخدم السيرفر وركر الجديد فورا
      return self.clients.claim();
    }).then(() => {
      // ابعت رسالة لكل الصفحات تقولهم حدثو نفسكم
      return self.clients.matchAll({type: 'window'}).then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: 'SW_UPDATED',
            version: CACHE_VERSION,
            message: 'تم تحديث التطبيق - اعادة تحميل'
          });
        });
      });
    })
  );
});

// MESSAGE - يستمع لرسالة "حدث نفسك فورا"
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (event.data && event.data.type === 'FORCE_UPDATE') {
    // مسح كل الكاش واعادة التحميل
    caches.keys().then((names) => {
      names.forEach((name) => caches.delete(name));
    }).then(() => {
      self.skipWaiting();
    });
  }
});

// FETCH - استراتيجية احترافية زي العمالقة (تويتر، حراج)
self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);

  // لا تكاش صفحات API او طلبات POST
  if (request.method !== 'GET') return;
  if (url.pathname.startsWith('/api/')) return;
  if (url.search.includes('nocache')) return;

  // 1. للصفحات (HTML) - Network First (يجبر آخر تحديث)
  if (request.mode === 'navigate' || request.headers.get('accept')?.includes('text/html')) {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          // حدث الكاش بالنسخة الجديدة من الشبكة
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return networkResponse;
        })
        .catch(() => {
          // لو النت مقطوع، جيب من الكاش
          return caches.match(request).then((cached) => {
            return cached || caches.match('./index.html');
          });
        })
    );
    return;
  }

  // 2. للملفات المهمة (CSS, JS, JSON) - Stale While Revalidate مع اجبار التحديث
  if ((url.origin === self.location.origin && (url.pathname.endsWith('.css') || url.pathname.endsWith('.js'))) ||
      request.url.includes('style.css') || 
      request.url.includes('app.js') || 
      request.url.includes('manifest.json') ||
      url.pathname.endsWith('.json') ||
      url.pathname.endsWith('.xml') ||
      url.pathname.endsWith('.txt')) {
    event.respondWith(
      fetch(request, {cache: 'no-store'}) // اجبر المتصفح يجيب من الشبكة بدون كاش
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return networkResponse;
        })
        .catch(() => {
          return caches.match(request);
        })
    );
    return;
  }

  // 3. للصور والخطوط - Cache First مع تحديث في الخلفية
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request).then((networkResponse) => {
        if (networkResponse && (networkResponse.status === 200 || networkResponse.type === 'opaque')) {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return networkResponse;
      }).catch(() => cachedResponse);

      // ارجع الكاش فورا، وحدث في الخلفية
      return cachedResponse || fetchPromise;
    })
  );
});

// Background Sync - للاعلانات اللي ما انبعتتش بسبب النت
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-ads') {
    event.waitUntil(
      // هنا تقدر تبعت الاعلانات المعلقة
      console.log('[SW v6.2] Syncing ads...')
    );
  }
});
