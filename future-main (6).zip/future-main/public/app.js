/* 🦁 Liogram - Professional v6.2 - 2026 Standards - Only publish opens filter - Images on first 2 levels + Back button */
(function(){
"use strict";

// Splash - prevent flash
try{
  if(sessionStorage.getItem('splashShown')){
    document.documentElement.classList.add('no-splash');
  }
}catch(e){}

document.addEventListener("DOMContentLoaded", function(){
  var splash = document.getElementById('lion-splash');
  try{
    if(sessionStorage.getItem('splashShown')){
      if(splash) splash.remove();
      return;
    }
  }catch(e){}
  if(!splash) return;
  setTimeout(function(){
    splash.style.opacity = '0';
    setTimeout(function(){
      try{ splash.remove(); }catch(e){}
      try{ sessionStorage.setItem('splashShown','true'); }catch(e){}
    },500);
  },1000);
});

// Prevent zoom iOS
document.addEventListener('touchstart', function(e){
  if(e.touches.length>1) e.preventDefault();
}, {passive:false});
var lastTouchEnd = 0;
document.addEventListener('touchend', function(e){
  var now = Date.now();
  if(now - lastTouchEnd <= 300) e.preventDefault();
  lastTouchEnd = now;
}, {passive:false});

// PWA - scoped, no global pollution
(function(){
  var deferredPrompt = null;
  if('serviceWorker' in navigator){
    window.addEventListener('load', function(){
      navigator.serviceWorker.register('./sw.js').catch(function(){});
    });
  }
  window.addEventListener('beforeinstallprompt', function(e){
    e.preventDefault();
    deferredPrompt = e;
  });
  document.addEventListener('click', function(e){
    if(!e.target.closest('.lion-page-install-btn')) return;
    if(!deferredPrompt) return;
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then(function(){ deferredPrompt = null; }).catch(function(){ deferredPrompt = null; });
  });
})();

// Feature tabs
document.querySelectorAll('input[name="feature"]').forEach(function(radio){
  radio.addEventListener('change', function(){
    var lionPage = document.getElementById('lion-app-content');
    var listings = document.querySelector('.listings');
    var isLionTab = !!radio.closest('#tab-lion-app');
    if(lionPage) lionPage.style.display = isLionTab ? 'block' : 'none';
    if(listings) listings.style.display = isLionTab ? 'none' : 'flex';
  });
});

/* ========================================================================
   🦁 Lion Filter Engine — نشر فقط يفتح النافذة
   - الصورة تظهر للمستوى الأول + الفروع الأولى فقط (depth <=1)
   - الفروع العميقة بدون صور
   - زر رجوع عند انقلاب البطاقة
   ======================================================================== */
(function(){
  "use strict";
  var LF_CURRENCY_BY_COUNTRY = {
    ly:"د.ل", eg:"ج.م", sa:"ر.س", ae:"د.إ", qa:"ر.ق", kw:"د.ك",
    bh:"د.ب", om:"ر.ع", jo:"د.أ", iq:"د.ع", sy:"ل.س", lb:"ل.ل",
    ye:"ر.ي", ma:"د.م", tn:"د.ت", dz:"د.ج", sd:"ج.س", ps:"₪"
  };
  var lfPhotos = [];
  var lfCurrentSelection = [];
  var lfLastFocused = null;
  var $overlay,$modal,$treeRoot,$breadcrumb,$publishBreadcrumb,$closeTree,$closePublish,$backBtn,$publishForm,$priceGroup,$priceInput,$currencySpan,$titleInput,$descInput,$photosGrid,$photoInput,$photoAddBtn,$photoCount,$toast;

  function lfInit(){
    $overlay = document.getElementById("lfOverlay"); if(!$overlay) return;
    $modal = document.getElementById("lfModal");
    $treeRoot = document.getElementById("lfTreeRoot");
    $breadcrumb = document.getElementById("lfBreadcrumb");
    $publishBreadcrumb = document.getElementById("lfPublishBreadcrumb");
    $closeTree = document.getElementById("lfCloseTree");
    $closePublish = document.getElementById("lfClosePublish");
    $backBtn = document.getElementById("lfBackBtn");
    $publishForm = document.getElementById("lfPublishForm");
    $priceGroup = document.getElementById("lfPriceGroup");
    $priceInput = document.getElementById("lfPriceInput");
    $currencySpan = document.getElementById("lfCurrency");
    $titleInput = document.getElementById("lfTitleInput");
    $descInput = document.getElementById("lfDescInput");
    $photosGrid = document.getElementById("lfPhotosGrid");
    $photoInput = document.getElementById("lfPhotoInput");
    $photoAddBtn = document.getElementById("lfPhotoAddBtn");
    $photoCount = document.getElementById("lfPhotoCount");
    $toast = document.getElementById("lfToast");

    var publishBtn = document.querySelector(".publish-btn");
    if(publishBtn) publishBtn.addEventListener("click", function(){ lfOpen("publish"); });
    var tripBtn = document.getElementById("lfTripBtn");
    if(tripBtn) tripBtn.addEventListener("click", function(){ lfGoToPublish(["رحلة"], { standalone: true }); });

    $overlay.addEventListener("click", function(e){ if(e.target === $overlay) lfClose(); });
    if($closeTree) $closeTree.addEventListener("click", lfClose);
    if($closePublish) $closePublish.addEventListener("click", lfClose);
    if($backBtn) $backBtn.addEventListener("click", function(){ $modal.classList.remove("lf-flipped"); });

    document.addEventListener("keydown", function(e){
      if(!$overlay.classList.contains("lf-open")) return;
      if(e.key === "Escape"){ 
        if($modal.classList.contains("lf-flipped")) $modal.classList.remove("lf-flipped");
        else lfClose();
        return;
      }
      if(e.key === "Tab") lfTrapFocus(e);
    });

    if($photoAddBtn) $photoAddBtn.addEventListener("click", function(){ $photoInput.click(); });
    if($photoInput) $photoInput.addEventListener("change", lfHandlePhotos);
    if($publishForm) $publishForm.addEventListener("submit", lfHandleSubmit);
    lfSetCurrency();
  }

  function lfOpen(mode){
    lfLastFocused = document.activeElement;
    $overlay.classList.add("lf-open");
    $overlay.style.display = "flex";
    document.body.style.overflow = "hidden";
    $modal.classList.remove("lf-flipped");
    lfSetCurrency();


    setTimeout(function(){
      var first = lfFocusable()[0];
      if(first) first.focus();
    }, 30);
  }

  function lfClose(){
    $overlay.classList.remove("lf-open");
    $overlay.style.display = "none";
    document.body.style.overflow = "";
    setTimeout(function(){ $modal.classList.remove("lf-flipped"); }, 200);
    if(lfLastFocused && typeof lfLastFocused.focus === "function") lfLastFocused.focus();
  }

  function lfFocusable(){
    var sel = 'button, a[href], input, textarea, select, summary, [tabindex]:not([tabindex="-1"])';
    return Array.prototype.slice.call($overlay.querySelectorAll(sel))
      .filter(function(el){ return el.offsetParent !== null; });
  }
  function lfTrapFocus(e){
    var items = lfFocusable();
    if(!items.length) return;
    var first = items[0], last = items[items.length-1];
    if(e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
    else if(!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
  }

  function lfGoToPublish(chain, node){
    lfCurrentSelection = chain;
    if($publishBreadcrumb){
      $publishBreadcrumb.innerHTML = chain.map(function(p){ return "<span>" + String(p).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;") + "</span>"; }).join(" ← ");
    }
    lfSetCurrency();
    var isBlander = !!(node && node.standalone);
    if($priceGroup){
      $priceGroup.style.display = isBlander ? "none" : "";
      if($priceInput) $priceInput.required = !isBlander;
    }
    $modal.classList.add("lf-flipped");
    setTimeout(function(){
      var first = $publishForm ? $publishForm.querySelector("input, textarea, button") : null;
      if(first) first.focus();
    }, 550);
  }

  function lfHandlePhotos(e){
    var files = Array.prototype.slice.call(e.target.files||[]);
    files.slice(0,10-lfPhotos.length).forEach(function(file){
      var reader = new FileReader();
      reader.onload=function(ev){ lfPhotos.push(ev.target.result); lfRenderPhotos(); };
      reader.readAsDataURL(file);
    });
    e.target.value="";
  }

  function lfRenderPhotos(){
    if(!$photosGrid) return;
    $photosGrid.querySelectorAll(".lf-photo-thumb").forEach(function(t){ t.remove(); });
    lfPhotos.forEach(function(src,i){
      var div = document.createElement("div");
      div.className="lf-photo-thumb";
      div.innerHTML='<img src="'+src+'" alt="" loading="lazy"><button class="lf-photo-remove" type="button" data-i="'+i+'">&times;</button>';
      div.querySelector(".lf-photo-remove").addEventListener("click", function(){ lfPhotos.splice(i,1); lfRenderPhotos(); });
      $photosGrid.insertBefore(div, $photoAddBtn);
    });
    if($photoCount) $photoCount.textContent=lfPhotos.length+" / 10";
    if($photoAddBtn) $photoAddBtn.style.display = lfPhotos.length>=10 ? "none" : "flex";
  }

  function lfSetCurrency(){
    var symbol = "د.ل";
    try{
      var flag = document.getElementById("user-flag");
      if(flag && flag.src){
        var m = flag.src.match(/\/([a-z]{2})\.png/i);
        if(m && LF_CURRENCY_BY_COUNTRY[m[1].toLowerCase()]) symbol = LF_CURRENCY_BY_COUNTRY[m[1].toLowerCase()];
      }
    }catch(err){}
    if($currencySpan) $currencySpan.textContent = symbol;
  }

  function lfHandleSubmit(e){
    e.preventDefault();
    var payload = {
      path: lfCurrentSelection,
      title: $titleInput.value.trim(),
      description: $descInput.value.trim(),
      price: $priceGroup.style.display === "none" ? null : Number($priceInput.value || 0),
      currency: $currencySpan ? $currencySpan.textContent : "د.ل",
      photosCount: lfPhotos.length
    };
    if(!payload.title){ lfToast("يرجى كتابة عنوان للإعلان"); return; }
    if(payload.price!==null && (!payload.price || payload.price<1 || payload.price>30000000)){
      lfToast("يرجى إدخال سعر صحيح"); return;
    }
    console.log("LION PUBLISH PAYLOAD →", payload);
    try{ sessionStorage.setItem("lion_last_publish", JSON.stringify(payload)); }catch(err){}
    document.dispatchEvent(new CustomEvent("lion:publish",{detail:payload}));
    lfToast("تم إعداد بيانات الإعلان — بانتظار ربط الخادم");
    setTimeout(function(){
      lfClose(); $publishForm.reset(); lfPhotos=[]; lfRenderPhotos(); $modal.classList.remove("lf-flipped");
    },1200);
  }

  var lfToastTimer=null;
  function lfToast(msg){
    if(!$toast) return;
    $toast.textContent=msg;
    $toast.classList.add("lf-show");
    clearTimeout(lfToastTimer);
    lfToastTimer=setTimeout(function(){ $toast.classList.remove("lf-show"); },2600);
  }

  document.addEventListener("DOMContentLoaded", lfInit);
})();

(function(){
  "use strict";
  var LION_MOCK_LISTINGS=[
    {emoji:"🎸", avatarLetter:"S", firstName:"ahmed", lastName:"salem", timeAgo:"1 س", title:"آلة عود شرقي احترافي، خشب روزوود، جديد، صوت نقي وقوي، صناعة يدوية، مع حقيبة مبطنة", shareCount:21}
  ];
  /* 🔒 تعقيم أي نص قادم من المستخدم قبل إدخاله في HTML (يمنع حقن الأكواد XSS) */
  function lionEsc(s){
    return String(s == null ? "" : s)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
  }
  function lionBuildCard(item){
    var card=document.createElement("div"); card.className="card";
    card.innerHTML='<div class="emoji" aria-hidden="true">'+lionEsc(item.emoji)+'</div><div class="info"><div class="publisher-row"><div class="publisher"><div class="avatar">'+lionEsc(item.avatarLetter)+'</div><div class="publisher-details"><span class="time-ago">'+lionEsc(item.timeAgo)+' <img src="img/clik.png" alt="وقت" width="14" height="14" loading="lazy"></span><span class="publisher-name"><span>'+lionEsc(item.firstName)+'</span><span>'+lionEsc(item.lastName)+'</span></span></div></div><button class="follow-btn" type="button"><span class="follow-text">متابعة</span></button></div><div class="unified-title-row">'+lionEsc(item.title)+'</div><div class="reaction-row"><span class="like-button-wrapper"><img src="img/haert.png" alt="قلب" width="25" height="22" loading="lazy"><div class="reaction-bar"><span class="reaction-emoji">😂</span><span class="reaction-emoji">🔥</span><span class="reaction-emoji">🙂</span><span class="reaction-emoji">❤️</span><span class="reaction-emoji">😢</span></div></span><span><img src="img/Pen.png" alt="تعليق" width="25" height="23" loading="lazy"></span><div class="share-info"><span class="share-count">'+lionEsc(item.shareCount)+'</span><img src="img/shar.png" alt="مشاركة" width="32" height="32" loading="lazy"></div></div></div>';
    return card;
  }
  function lionRenderListings(items){
    var root=document.getElementById("lionListings"); if(!root) return;
    root.innerHTML=""; items.forEach(function(item){ root.appendChild(lionBuildCard(item)); });
  }
  document.addEventListener("DOMContentLoaded", function(){ lionRenderListings(LION_MOCK_LISTINGS); });
  /* يُستخدم من الملف الشخصي لعرض البطاقات بنفس الشكل */
  window.LionCards = { build: lionBuildCard, sample: LION_MOCK_LISTINGS };
})();

})();



/* ============================================================
   🍔 كود فتح وإغلاق القائمة الجانبية (Sidebar Menu)
   ضع هذا الكود في نهاية ملف app.js الخاص بك
   ============================================================ */
(function () {
  var menuBtn        = document.querySelector('.menu-btn');
  var sidebarMenu     = document.getElementById('sidebarMenu');
  var sidebarOverlay  = document.getElementById('sidebarOverlay');
  var sidebarCloseBtn = document.getElementById('sidebarCloseBtn');

  if (!menuBtn || !sidebarMenu || !sidebarOverlay || !sidebarCloseBtn) return;

  function openSidebar() {
    sidebarMenu.classList.add('sidebar-open');
    sidebarOverlay.classList.add('sidebar-open');
    sidebarMenu.setAttribute('aria-hidden', 'false');
    document.body.classList.add('sidebar-locked');
  }

  function closeSidebar() {
    sidebarMenu.classList.remove('sidebar-open');
    sidebarOverlay.classList.remove('sidebar-open');
    sidebarMenu.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('sidebar-locked');
  }

  // فتح القائمة عند الضغط على أيقونة البرجر في الهيدر
  menuBtn.addEventListener('click', openSidebar);

  // إغلاق القائمة عند الضغط على زر الإغلاق (X)
  sidebarCloseBtn.addEventListener('click', closeSidebar);

  // إغلاق القائمة عند الضغط على الخلفية المعتمة
  sidebarOverlay.addEventListener('click', closeSidebar);

  // إغلاق القائمة عند الضغط على مفتاح Escape
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && sidebarMenu.classList.contains('sidebar-open')) {
      closeSidebar();
    }
  });
})();


/* ============================================================
   🔔 نظام الإشعارات (لا توجد رسائل)
   - يُفتح ويُغلق بالضغط على الجرس في الهيدر
   - نوعان فقط: تعليق على رحلتك + تفاعل على رحلتك
   - البيانات الآن تجريبية (SAMPLE_DATA) لمعاينة الشكل، وتُستبدل بـ /api/notifications عند الربط
   ============================================================ */
(function () {
  "use strict";

  var bellBtn = document.getElementById('bellBtn');
  var overlay = document.getElementById('ntOverlay');
  var badge   = document.getElementById('bellBadge');
  if (!bellBtn || !overlay || !badge) return;

  /* ---------- 1) عبارات الإشعارات ----------
     { المفتاح: 'نص العبارة وفيه {name} مكان اسم الشخص' }                 */
  var TEMPLATES = {
    trip_comment:  'قام {name} بتعليق علي رحلتك',
    trip_reaction: 'تفاعل {name} علي رحلتك'
  };

  /* ---------- 2) الصورة الافتراضية عند غياب صورة المستخدم ---------- */
  var DEFAULT_AVATAR = 'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" fill="#e6e6e6"/><path fill="#888" d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>'
  );

  var MIN = 60000, HOUR = 3600000, DAY = 86400000;

  /* ---------- 3) مصدر البيانات — هنا فقط تُستبدل عند جاهزية الباك اند ----------
     عناصر المصفوفة: { id, type, name, avatar, time, read }
        type = trip_comment أو trip_reaction ، time = توقيت بالميلي ثانية
     عند الربط: احذف SAMPLE_DATA وفعّل سطر fetch (الباك اند يرجع { items } بنفس الشكل) */
  function sampleData() {                                   // SAMPLE_DATA (للمعاينة فقط)
    var now = Date.now();
    return [
      { id: 's1', type: 'trip_comment',  name: 'أحمد سالم',   avatar: '', time: now - 5 * MIN,   read: false },
      { id: 's2', type: 'trip_reaction', name: 'رنا عبدالله', avatar: '', time: now - 40 * MIN,  read: false },
      { id: 's3', type: 'trip_comment',  name: 'محمد علي',    avatar: '', time: now - 3 * HOUR,  read: true  },
      { id: 's4', type: 'trip_reaction', name: 'سارة محمود',  avatar: '', time: now - 2 * DAY,   read: true  }
    ];
  }
  function loadNotifications() {
    return Promise.resolve(sampleData());
    // return fetch('/api/notifications').then(function (r) { return r.json(); }).then(function (d) { return d.items; });
  }

  /* ---------- 4) الوقت بالعربية ---------- */
  function unitText(n, forms) {
    if (n === 1) return forms[0];
    if (n === 2) return forms[1];
    return n + ' ' + (n <= 10 ? forms[2] : forms[3]);
  }
  function timeAgo(ts) {
    var diff = Math.max(0, Date.now() - ts);
    if (diff < MIN) return 'الآن';
    var m = Math.floor(diff / MIN);
    if (m < 60) return 'قبل ' + unitText(m, ['دقيقة', 'دقيقتين', 'دقائق', 'دقيقة']);
    var h = Math.floor(diff / HOUR);
    if (h < 24) return 'قبل ' + unitText(h, ['ساعة', 'ساعتين', 'ساعات', 'ساعة']);
    var d = Math.floor(diff / DAY);
    if (d < 30) return 'قبل ' + unitText(d, ['يوم', 'يومين', 'أيام', 'يوماً']);
    var mo = Math.floor(d / 30);
    return 'قبل ' + unitText(mo, ['شهر', 'شهرين', 'أشهر', 'شهراً']);
  }

  /* ---------- 5) الحالة والعناصر ---------- */
  var notifications = [];
  var panel = document.getElementById('panelNotifications');

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function avatarImg(src, name) {
    var img = el('img', 'nt-avatar');
    img.src = src || DEFAULT_AVATAR;
    img.alt = name;
    img.onerror = function () { img.onerror = null; img.src = DEFAULT_AVATAR; };
    return img;
  }

  /* ---------- 6) بناء بطاقة إشعار (سطر واحد) ---------- */
  function buildNotifItem(n) {
    var tpl  = TEMPLATES[n.type] || '{name}';
    var item = el('li', 'nt-item' + (n.read ? '' : ' is-unread'));
    var row  = el('div', 'nt-row');
    var side = el('div', 'nt-side');

    side.appendChild(avatarImg(n.avatar, n.name));
    side.appendChild(el('span', 'nt-time', timeAgo(n.time)));
    row.appendChild(side);
    row.appendChild(el('p', 'nt-text nt-notif-text', tpl.replace('{name}', n.name)));
    item.appendChild(row);
    item.appendChild(el('div', 'nt-sep'));

    item.addEventListener('click', function () {
      if (!n.read) { n.read = true; render(); }
    });
    return item;
  }

  function render() {
    panel.textContent = '';
    if (!notifications.length) {
      var box = el('div', 'nt-empty');
      box.appendChild(el('strong', null, 'لا توجد إشعارات'));
      box.appendChild(el('span', null, 'ستظهر هنا تعليقات وتفاعلات الآخرين على رحلاتك'));
      panel.appendChild(box);
    } else {
      var list = el('ul', 'nt-list');
      notifications.slice().sort(function (a, b) { return b.time - a.time; })
        .forEach(function (n) { list.appendChild(buildNotifItem(n)); });
      panel.appendChild(list);
    }
    updateBadge();
  }

  /* العلامة الحمراء = عدد الإشعارات غير المقروءة */
  function updateBadge() {
    var unread = notifications.filter(function (n) { return !n.read; }).length;
    badge.textContent = unread > 99 ? '99+' : unread;
    badge.hidden = unread === 0;
  }

  /* ---------- 7) فتح / إغلاق النافذة بالجرس ---------- */
  function setOpen(open) {
    overlay.classList.toggle('nt-open', open);
    overlay.setAttribute('aria-hidden', open ? 'false' : 'true');
    if (open) overlay.scrollTop = 0;
  }
  bellBtn.addEventListener('click', function () {
    setOpen(!overlay.classList.contains('nt-open'));
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay.classList.contains('nt-open')) setOpen(false);
  });

  /* تحديث "قبل دقيقتين" تلقائياً كل دقيقة */
  setInterval(render, MIN);

  /* ---------- تشغيل ---------- */
  render();
  loadNotifications()
    .then(function (items) { notifications = Array.isArray(items) ? items : []; render(); })
    .catch(function () { render(); });
})();


/* ============================================================
   👤 الملف الشخصي
   - يُفتح من "حسابي" في البار السفلي (أو "الملف الشخصي" في القائمة الجانبية)
   - كل خانة فارغة تبدأ بسؤال، والضغط عليها يحوّلها لحقل كتابة في نفس المكان
   - البيانات تُحفظ مؤقتاً في المتصفح حتى يُربط الباك اند (انظر loadProfile / saveProfile)
   ============================================================ */
(function () {
  "use strict";

  var view = document.getElementById('pfView');
  if (!view) return;

  /* ---------- إعدادات ---------- */
  var OWNER = true;            // true = صاحب الحساب (تعديل) ، false = زائر (عرض + متابعة)
  var TEST_CARDS = true;       // 🧪 true = يعرض بطاقات تجريبية للمعاينة ، false = يبدأ بلا بطاقات (غيّرها للنهائي)
  var STORE_KEY = 'lion_profile_v1';

  var TYPES = { store: 'متجر', advertiser: 'معلن', blender: 'بلانديور' };
  var BASE = {
    facebook:  'https://www.facebook.com/',
    instagram: 'https://www.instagram.com/',
    tiktok:    'https://www.tiktok.com/@',
    youtube:   'https://www.youtube.com/@'
  };
  var PLATFORM_NAMES = { facebook: 'فيسبوك', instagram: 'إنستغرام', tiktok: 'تيك توك', youtube: 'يوتيوب' };
  var ICONS = {
    facebook:  '<svg viewBox="0 0 24 24"><path fill="#1877F2" d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z"/></svg>',
    instagram: '<svg viewBox="0 0 24 24"><defs><linearGradient id="pfIg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#FEDA75"/><stop offset=".3" stop-color="#FA7E1E"/><stop offset=".55" stop-color="#D62976"/><stop offset=".8" stop-color="#962FBF"/><stop offset="1" stop-color="#4F5BD5"/></linearGradient></defs><rect width="24" height="24" rx="6" fill="url(#pfIg)"/><rect x="5" y="5" width="14" height="14" rx="4.2" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="12" cy="12" r="3.3" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="16.4" cy="7.6" r="1.1" fill="#fff"/></svg>',
    tiktok:    '<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="6" fill="#000"/><path d="M13.2 5.5v8.6a2.6 2.6 0 1 1-2.6-2.6" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"/><path d="M13.2 5.5c.3 1.9 1.6 3.1 3.6 3.3" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>',
    youtube:   '<svg viewBox="0 0 24 24"><rect x="1" y="4.5" width="22" height="15" rx="4.5" fill="#FF0000"/><path d="M10 9l5.5 3L10 15z" fill="#fff"/></svg>',
    /* أيقونة الرسائل: نفس أيقونة تبويب الرسائل في صندوق الإشعارات */
    message:   '<svg viewBox="0 0 24 24"><path d="M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H9l-4 4v-4H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/><rect x="6.5" y="8.3" width="11" height="1.7" rx=".85" fill="#fff"/><rect x="6.5" y="12" width="7.5" height="1.7" rx=".85" fill="#fff"/></svg>',
    clock:     '<svg class="pf-clock" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9.5" fill="none" stroke-width="2.2"/><path d="M12 6.5V12l3.6 2.2" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  /* ---------- البيانات ---------- */
  function emptyProfile() {
    return { name: '', type: '', field: '', followers: 0, loc: '', socials: [], whatsapp: '',
             bio: '', hours: null, avatar: '', cover: '', coverPos: { x: 50, y: 50 } };
  }
  function clean(d) {
    var p = emptyProfile();
    if (!d || typeof d !== 'object') return p;
    ['name', 'field', 'loc', 'bio', 'whatsapp'].forEach(function (k) { if (typeof d[k] === 'string') p[k] = d[k]; });
    if (TYPES[d.type]) p.type = d.type;
    if (typeof d.followers === 'number' && d.followers > 0) p.followers = d.followers;
    if (Array.isArray(d.socials)) {
      d.socials.slice(0, 2).forEach(function (s) {
        if (s && BASE[s.platform] && typeof s.value === 'string') p.socials.push({ platform: s.platform, value: s.value });
      });
    }
    if (d.hours && /^\d\d:\d\d$/.test(d.hours.from) && /^\d\d:\d\d$/.test(d.hours.to)) p.hours = { from: d.hours.from, to: d.hours.to };
    if (typeof d.avatar === 'string' && /^(data:image\/|https?:\/\/)/.test(d.avatar)) p.avatar = d.avatar;
    if (typeof d.cover === 'string' && /^(data:image\/|https?:\/\/)/.test(d.cover)) p.cover = d.cover;
    if (d.coverPos && isFinite(d.coverPos.x) && isFinite(d.coverPos.y)) p.coverPos = { x: +d.coverPos.x, y: +d.coverPos.y };
    return p;
  }

  /* مصدر البيانات — هنا فقط تُستبدل عند جاهزية الباك اند
     مستقبلاً: return fetch('/api/profile').then(function (r) { return r.json(); }) */
  function loadProfile() {
    try { return clean(JSON.parse(localStorage.getItem(STORE_KEY))); } catch (e) { return emptyProfile(); }
  }
  /* حفظ التعديلات — مستقبلاً: fetch('/api/profile', { method: 'POST', body: JSON.stringify(p) }) */
  var warned = false;
  function saveProfile() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(p)); }
    catch (e) { if (!warned) { warned = true; toast('تعذر حفظ التعديلات على هذا الجهاز'); } }
    document.dispatchEvent(new CustomEvent('lion:profile-save', { detail: p }));
  }

  var p = loadProfile();
  var following = false;
  var active = null;      // الحقل المفتوح للتعديل حالياً

  /* ---------- أدوات ---------- */
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function $(id) { return document.getElementById(id); }
  var toastEl = $('lfToast'), toastTimer = null;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('lf-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('lf-show'); }, 2000);
  }
  function clamp(n) { return Math.max(0, Math.min(100, n)); }

  var rows = {
    name: $('pfRowName'), type: $('pfRowType'), loc: $('pfRowLoc'),
    bio: $('pfRowBio'), hours: $('pfRowHours')
  };
  var btn = {};
  Array.prototype.forEach.call(view.querySelectorAll('[data-k]'), function (b) { btn[b.dataset.k] = b; });
  var socialsBox = $('pfSocials'), followBtn = $('pfFollow'), hoursBtn = $('pfHours');
  var followersEl = $('pfFollowers'), headEl = $('pfHead'), cardsBox = $('pfCards');

  /* ---------- التعديل المباشر ---------- */
  function mkOk() { var b = el('button', 'pf-ok', 'موافق'); b.type = 'button'; return b; }

  function openEditor(row, build) {
    if (!closeActive(true)) return;
    var box = el('div', 'pf-ed');
    var api = build(box);
    row.classList.add('pf-editing');
    row.appendChild(box);
    active = { row: row, box: box, commit: api.commit };
  }
  function closeActive(commit) {
    if (!active) return true;
    var a = active;
    if (commit) {
      if (a.commit() === false) return false;
      saveProfile();
    }
    active = null;
    a.box.remove();
    a.row.classList.remove('pf-editing');
    render();
    return true;
  }

  function textEditor(row, o) {
    openEditor(row, function (box) {
      var inp = el(o.multi ? 'textarea' : 'input', 'pf-input');
      if (!o.multi) inp.type = 'text'; else inp.rows = 4;
      inp.maxLength = o.max;
      inp.value = o.value || '';
      inp.placeholder = o.ph;
      box.appendChild(inp);
      if (o.multi) {
        var cnt = el('div', 'pf-hint');
        var upd = function () { cnt.textContent = inp.value.length + ' / ' + o.max; };
        inp.addEventListener('input', upd); upd();
        box.appendChild(cnt);
      } else {
        inp.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); closeActive(true); }
        });
      }
      var ok = mkOk();
      ok.addEventListener('click', function () { closeActive(true); });
      box.appendChild(ok);
      setTimeout(function () { inp.focus(); try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) {} }, 0);
      return { commit: function () { o.save(inp.value.replace(/\s+/g, ' ').trim()); } };
    });
  }

  function typeEditor() {
    openEditor(rows.type, function (box) {
      var sel = p.type;
      var chips = el('div', 'pf-chips');
      Object.keys(TYPES).forEach(function (k) {
        var c = el('button', 'pf-chip' + (k === sel ? ' is-sel' : ''), TYPES[k]);
        c.type = 'button';
        c.addEventListener('click', function () {
          sel = k;
          Array.prototype.forEach.call(chips.children, function (x) { x.classList.remove('is-sel'); });
          c.classList.add('is-sel');
        });
        chips.appendChild(c);
      });
      box.appendChild(chips);
      var ok = mkOk();
      ok.addEventListener('click', function () { closeActive(true); });
      box.appendChild(ok);
      return { commit: function () { p.type = sel; } };
    });
  }

  function buildUrl(platform, v) {
    v = (v || '').trim();
    if (!v) return '';
    if (/^https?:\/\//i.test(v)) {
      try { var u = new URL(v); return (u.protocol === 'http:' || u.protocol === 'https:') ? u.href : ''; } catch (e) { return ''; }
    }
    v = v.replace(/^@/, '').replace(/\s+/g, '');
    if (!/^[\w.\-]+$/.test(v)) return '';
    return BASE[platform] + v;
  }
  function waDigits(v) { return String(v || '').replace(/\D/g, ''); }

  function socialsEditor() {
    openEditor(rows.loc, function (box) {
      var slots = [];
      for (var i = 0; i < 2; i++) {
        var cur = p.socials[i];
        var wrap = el('div', 'pf-soc-slot');
        var sel = el('select', 'pf-input');
        var o0 = el('option', null, 'اختر المنصة'); o0.value = '';
        sel.appendChild(o0);
        Object.keys(PLATFORM_NAMES).forEach(function (k) {
          var o = el('option', null, PLATFORM_NAMES[k]); o.value = k;
          sel.appendChild(o);
        });
        var inp = el('input', 'pf-input');
        inp.type = 'text'; inp.placeholder = 'اسم الحساب أو الرابط'; inp.maxLength = 200;
        inp.setAttribute('autocapitalize', 'none'); inp.setAttribute('autocomplete', 'off');
        if (cur) { sel.value = cur.platform; inp.value = cur.value; }
        wrap.appendChild(sel); wrap.appendChild(inp);
        box.appendChild(wrap);
        slots.push({ sel: sel, inp: inp });
      }
      var wa = el('input', 'pf-input');
      wa.type = 'tel'; wa.placeholder = 'رقم واتساب مع رمز الدولة'; wa.maxLength = 20;
      wa.style.fontSize = '14px'; wa.style.direction = 'ltr';
      wa.value = p.whatsapp || '';
      box.appendChild(wa);
      box.appendChild(el('div', 'pf-hint', 'حتى منصتين خارجيتين، وأيقونة الرسائل للتواصل المباشر عبر واتساب'));
      var ok = mkOk();
      ok.addEventListener('click', function () { closeActive(true); });
      box.appendChild(ok);

      return { commit: function () {
        var list = [], seen = {};
        for (var i = 0; i < slots.length; i++) {
          var plat = slots[i].sel.value, val = slots[i].inp.value.trim();
          if (!plat && !val) continue;
          if (!plat || !val) { toast('اختر المنصة واكتب الحساب'); return false; }
          if (!buildUrl(plat, val)) { toast('حساب ' + PLATFORM_NAMES[plat] + ' غير صالح'); return false; }
          if (seen[plat]) { toast('اخترت المنصة نفسها مرتين'); return false; }
          seen[plat] = 1;
          list.push({ platform: plat, value: val });
        }
        var d = waDigits(wa.value);
        if (d && (d.length < 8 || d.length > 15)) { toast('رقم واتساب غير صحيح'); return false; }
        p.socials = list;
        p.whatsapp = d;
      } };
    });
  }

  function hoursEditor() {
    openEditor(rows.hours, function (box) {
      var line = el('div', 'pf-time-row');
      var from = el('input', 'pf-input'); from.type = 'time'; from.value = p.hours ? p.hours.from : '09:00';
      var to   = el('input', 'pf-input'); to.type = 'time';   to.value   = p.hours ? p.hours.to   : '17:00';
      line.appendChild(el('span', null, 'من')); line.appendChild(from);
      line.appendChild(el('span', null, 'إلى')); line.appendChild(to);
      box.appendChild(line);
      box.appendChild(el('div', 'pf-hint', 'مثال: من 09:00 إلى 22:00 — يدعم الدوام الذي يتخطى منتصف الليل'));
      var btns = el('div', 'pf-ed-btns');
      var ok = mkOk();
      ok.addEventListener('click', function () { closeActive(true); });
      btns.appendChild(ok);
      if (p.hours) {
        var rm = el('button', 'pf-ghost', 'إزالة'); rm.type = 'button';
        rm.addEventListener('click', function () { p.hours = null; closeActive(false); saveProfile(); render(); });
        btns.appendChild(rm);
      }
      box.appendChild(btns);
      return { commit: function () {
        if (!from.value || !to.value) { toast('حدد وقت الفتح والإغلاق'); return false; }
        p.hours = { from: from.value, to: to.value };
      } };
    });
  }

  function openEdit(k) {
    if (!OWNER) return;
    if (k === 'name')  return textEditor(rows.name,  { value: p.name,  max: 35,  ph: 'ما إسمك',            fs: 28, save: function (v) { p.name = v; } });
    if (k === 'field') return textEditor(rows.type,  { value: p.field, max: 30,  ph: 'ما مجالك',           fs: 16, save: function (v) { p.field = v; } });
    if (k === 'loc')   return textEditor(rows.loc,   { value: p.loc,   max: 30,  ph: 'أين تعيش',           fs: 16, save: function (v) { p.loc = v; } });
    if (k === 'bio')   return textEditor(rows.bio,   { value: p.bio,   max: 250, ph: 'اكتب وصفاً لما تقدمه', fs: 15, multi: true, save: function (v) { p.bio = v; } });
    if (k === 'type')  return typeEditor();
    if (k === 'soc')   return socialsEditor();
    if (k === 'hours') return hoursEditor();
  }

  view.addEventListener('click', function (e) {
    var t = e.target.closest('[data-k]');
    if (t && view.contains(t)) { openEdit(t.dataset.k); return; }
    var o = e.target.closest('[data-open]');
    if (o) {
      if (OWNER) openEdit('soc');
      else window.open(o.dataset.open, '_blank', 'noopener,noreferrer');
    }
  });
  hoursBtn.addEventListener('click', function () { openEdit('hours'); });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && active) closeActive(false);
  });

  /* ---------- الرسم ---------- */
  function setT(b, text, ph) {
    var empty = !text;
    b.textContent = empty ? ph : text;
    b.classList.toggle('pf-empty', empty);
    b.hidden = empty && !OWNER;
  }
  function followersText(n) {
    if (!n) return 'المتابعين';
    if (n >= 1000000) return (Math.round(n / 100000) / 10) + ' مليون متابع';
    if (n >= 1000) return (Math.round(n / 100) / 10) + ' ألف متابع';
    return n + ' متابع';
  }

  function renderSocials() {
    socialsBox.textContent = '';
    var any = false;
    p.socials.forEach(function (s) {
      var url = buildUrl(s.platform, s.value);
      if (!url) return;
      any = true;
      var b = el('button', 'pf-soc');
      b.type = 'button';
      b.dataset.open = url;
      b.setAttribute('aria-label', PLATFORM_NAMES[s.platform]);
      b.innerHTML = ICONS[s.platform];
      socialsBox.appendChild(b);
    });
    var d = waDigits(p.whatsapp);
    if (d) {
      any = true;
      var w = el('button', 'pf-soc pf-soc-wa');
      w.type = 'button';
      w.dataset.open = 'https://wa.me/' + d;
      w.setAttribute('aria-label', 'مراسلة عبر واتساب');
      w.innerHTML = ICONS.message;
      socialsBox.appendChild(w);
    }
    if (!any && OWNER) {
      var add = el('button', 'pf-t pf-empty', 'أضف منصات التواصل');
      add.type = 'button';
      add.dataset.k = 'soc';
      socialsBox.appendChild(add);
    }
    return any;
  }

  /* ساعات الدوام: عدّاد حقيقي ينقص كل دقيقة */
  function toMs(s) { var a = s.split(':'); return ((+a[0]) * 60 + (+a[1])) * 60000; }
  function hoursWord(h) { return h === 1 ? 'ساعة' : h === 2 ? 'ساعتين' : h <= 10 ? h + ' ساعات' : h + ' ساعة'; }
  function durText(mins) {
    var h = Math.floor(mins / 60), m = mins % 60, parts = [];
    if (h) parts.push(hoursWord(h));
    if (m) parts.push(m + ' د');
    return parts.join(' و ');
  }
  function hoursState() {
    var D = 86400000, f = toMs(p.hours.from), t = toMs(p.hours.to);
    if (f === t) return { open: true, text: 'مفتوح على مدار الساعة' };
    var n = new Date();
    var now = n.getHours() * 3600000 + n.getMinutes() * 60000 + n.getSeconds() * 1000 + n.getMilliseconds();
    var open = f < t ? (now >= f && now < t) : (now >= f || now < t);
    var diff = (open ? t : f) - now;
    if (diff <= 0) diff += D;
    var mins = Math.max(1, Math.ceil(diff / 60000));
    return { open: open, text: open ? 'يغلق بعد ' + durText(mins) : 'مغلق الآن، يفتح بعد ' + durText(mins) };
  }
  var lastHoursText = null;
  function renderHours(force) {
    if (!p.hours) {
      if (lastHoursText !== '' || force) {
        lastHoursText = '';
        hoursBtn.className = 'pf-hours';
        hoursBtn.textContent = 'هل تريد إضافة التوقيت وساعات الدوام ؟';
      }
      rows.hours.hidden = !OWNER;
      return;
    }
    rows.hours.hidden = false;
    var s = hoursState();
    if (s.text === lastHoursText && !force) return;
    lastHoursText = s.text;
    hoursBtn.className = 'pf-hours ' + (s.open ? 'is-open' : 'is-closed');
    hoursBtn.innerHTML = ICONS.clock;
    hoursBtn.appendChild(el('span', null, s.text));
  }
  setInterval(function () { if (!active || active.row !== rows.hours) renderHours(); }, 1000);

  function renderCards() {
    cardsBox.textContent = '';
    var items = (TEST_CARDS && window.LionCards) ? window.LionCards.sample : [];
    if (!items.length) {
      cardsBox.appendChild(el('div', 'pf-empty-cards', 'لا يوجد محتوى بعد'));
      return;
    }
    items.forEach(function (it) { cardsBox.appendChild(window.LionCards.build(it)); });
  }

  function renderCover() {
    var img = $('pfCoverImg');
    if (p.cover) {
      img.src = p.cover;
      img.style.objectPosition = p.coverPos.x + '% ' + p.coverPos.y + '%';
    }
    img.hidden = !p.cover;
    $('pfCoverEmpty').hidden = !!p.cover || !OWNER;
  }
  function renderAvatar() {
    var img = $('pfAvatarImg');
    if (p.avatar) img.src = p.avatar;
    img.hidden = !p.avatar;
    $('pfAvatarPh').hidden = !!p.avatar;
  }

  function renderFollow() {
    followBtn.textContent = (!OWNER && following) ? 'أنت تتابعه الآن' : 'مــتابعة';
    followBtn.classList.toggle('is-following', !OWNER && following);
  }

  function render() {
    view.classList.toggle('pf-owner', OWNER);
    setT(btn.name,  p.name,  'ما إسمك');
    setT(btn.type,  TYPES[p.type] || '', 'ما تصنيفك');
    setT(btn.field, p.field, 'ما مجالك');
    setT(btn.loc,   p.loc,   'أين تعيش');
    setT(btn.bio,   p.bio,   'اكتب وصفاً لما تقدمه');
    var typeDash = rows.type.querySelector('.pf-dash');
    typeDash.hidden = !OWNER && (!p.type || !p.field);
    followersEl.textContent = followersText(p.followers);
    var any = renderSocials();
    rows.loc.querySelector('.pf-dash').hidden = !OWNER && (!p.loc || !any);
    rows.name.hidden = !OWNER && !p.name;
    renderFollow();
    renderHours(true);
    renderAvatar();
    renderCover();
  }

  /* ---------- الصور ---------- */
  function readImage(file, maxSide, quality, cb) {
    if (!file || !/^image\//.test(file.type)) { toast('اختر صورة صالحة'); return; }
    var fr = new FileReader();
    fr.onerror = function () { toast('تعذر قراءة الصورة'); };
    fr.onload = function () {
      var im = new Image();
      im.onerror = function () { toast('تعذر قراءة الصورة'); };
      im.onload = function () {
        var s = Math.min(1, maxSide / Math.max(im.width, im.height));
        var c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(im.width * s));
        c.height = Math.max(1, Math.round(im.height * s));
        var g = c.getContext('2d');
        g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
        g.drawImage(im, 0, 0, c.width, c.height);
        cb(c.toDataURL('image/jpeg', quality));
      };
      im.src = fr.result;
    };
    fr.readAsDataURL(file);
  }

  var avatarInput = $('pfAvatarInput'), coverInput = $('pfCoverInput');
  $('pfAvatar').addEventListener('click', function () { if (OWNER) avatarInput.click(); });
  avatarInput.addEventListener('change', function () {
    var f = avatarInput.files && avatarInput.files[0];
    avatarInput.value = '';
    readImage(f, 640, 0.86, function (url) { p.avatar = url; saveProfile(); renderAvatar(); });
  });

  /* الغلاف: الضغط عليه يفتح تعديل الموضع (سحب بالإصبع في الاتجاهين) */
  var cover = $('pfCover'), coverImg = $('pfCoverImg'), coverBar = $('pfCoverBar');
  var repos = false, drag = null;
  function startRepos() { repos = true; cover.classList.add('is-repos'); coverBar.hidden = false; view.scrollTop = 0; }
  function endRepos() { repos = false; drag = null; cover.classList.remove('is-repos'); coverBar.hidden = true; saveProfile(); }

  cover.addEventListener('click', function (e) {
    if (!OWNER || e.target.closest('#pfCoverBar')) return;
    if (!p.cover) coverInput.click();
    else if (!repos) startRepos();
  });
  $('pfCoverChange').addEventListener('click', function () { coverInput.click(); });
  $('pfCoverOk').addEventListener('click', endRepos);
  coverInput.addEventListener('change', function () {
    var f = coverInput.files && coverInput.files[0];
    coverInput.value = '';
    readImage(f, 1400, 0.82, function (url) {
      p.cover = url; p.coverPos = { x: 50, y: 50 };
      saveProfile(); renderCover(); startRepos();
    });
  });
  cover.addEventListener('pointerdown', function (e) {
    if (!repos || e.target.closest('#pfCoverBar')) return;
    drag = { x: e.clientX, y: e.clientY, px: p.coverPos.x, py: p.coverPos.y };
    try { cover.setPointerCapture(e.pointerId); } catch (err) {}
  });
  cover.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var cw = cover.clientWidth, ch = cover.clientHeight;
    var iw = coverImg.naturalWidth, ih = coverImg.naturalHeight;
    if (!iw || !ih) return;
    var s = Math.max(cw / iw, ch / ih);
    var ox = iw * s - cw, oy = ih * s - ch;
    if (ox > 1) p.coverPos.x = clamp(drag.px - (e.clientX - drag.x) / ox * 100);
    if (oy > 1) p.coverPos.y = clamp(drag.py - (e.clientY - drag.y) / oy * 100);
    coverImg.style.objectPosition = p.coverPos.x + '% ' + p.coverPos.y + '%';
  });
  function stopDrag() { drag = null; }
  cover.addEventListener('pointerup', stopDrag);
  cover.addEventListener('pointercancel', stopDrag);

  /* ---------- المتابعة والمتحف ---------- */
  followBtn.addEventListener('click', function () {
    if (OWNER) { toast('لا تستطيع متابعة نفسك'); return; }
    following = !following;
    renderFollow();
    document.dispatchEvent(new CustomEvent('lion:follow', { detail: { following: following } }));
  });
  $('pfMuseum').addEventListener('click', function () {
    document.dispatchEvent(new CustomEvent('lion:museum-open'));   // يُربط لاحقاً بميزة المتحف
  });

  /* ---------- الفتح والإغلاق ---------- */
  var ntOverlay = $('ntOverlay');
  function closeNotifications() {
    if (!ntOverlay) return;
    ntOverlay.classList.remove('nt-open');
    ntOverlay.setAttribute('aria-hidden', 'true');
  }
  function openProfile() {
    closeNotifications();
    view.classList.add('pf-open');
    view.setAttribute('aria-hidden', 'false');
    renderHours(true);
  }
  function closeProfile() {
    closeActive(true);
    if (repos) endRepos();
    view.classList.remove('pf-open');
    view.setAttribute('aria-hidden', 'true');
  }

  var navProfile = document.querySelector('.bottom-nav [aria-label="حسابي"]');
  var navHome = document.querySelector('.bottom-nav [aria-label="الرئيسية"]');
  if (navProfile) navProfile.addEventListener('click', openProfile);
  if (navHome) navHome.addEventListener('click', function () { closeProfile(); closeNotifications(); });

  var bell = $('bellBtn');
  if (bell) bell.addEventListener('click', closeProfile);   // الجرس يفتح الإشعارات فوق أي شيء

  var sideProfile = document.querySelector('.sidebar-menu-list .sidebar-menu-item');
  if (sideProfile) sideProfile.addEventListener('click', function () {
    var c = $('sidebarCloseBtn'); if (c) c.click();
    openProfile();
  });

  /* ---------- واجهة للباك اند لاحقاً ---------- */
  window.LionProfile = {
    /* LionProfile.load(بيانات_الحساب, { owner: true/false }) */
    getAvatar: function () { return p.avatar; },
    load: function (data, opts) {
      p = clean(data);
      OWNER = !(opts && opts.owner === false);
      following = !!(opts && opts.following);
      render();
    }
  };

  render();
  renderCards();
})();


/* ============================================================
   🔐 تسجيل الدخول (Google) + القائمة الجانبية + النافذة الموحدة
   - حالة الدخول في مكان واحد: LionAuth.user (null = زائر)
   - عند الربط: استدعِ LionAuth.setUser({ name, photo }) بعد نجاح الدخول،
     و LionAuth.setUser(null) بعد الخروج
   - أي عنصر يتطلب دخولاً: أضف له data-auth="نص السبب" ، أو أضفه إلى GATES أدناه
   - ملاحظة: إخفاء الأزرار تنظيم للواجهة فقط، والحماية الحقيقية تكون في الباك اند
   ============================================================ */
(function () {
  "use strict";

  var overlay = document.getElementById('auOverlay');
  if (!overlay) return;

  var DEMO_LOGIN_PARAM = true;   // 🧪 true = الرابط ?demo-login=1 يعرض شكل المستخدم المسجّل للمعاينة (غيّرها إلى false عند الربط)

  var DEFAULT_AVATAR = 'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" fill="#e6e6e6"/><path fill="#888" d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>'
  );

  /* ---------- العناصر التي تتطلب دخولاً ---------- */
  var GATES = [
    { sel: '[data-auth]',          reason: function (el) { return el.getAttribute('data-auth'); } },
    { sel: '#sidebarAccountItem',  reason: 'سجّل دخولك للاستمتاع بكل مزايا الموقع' },
    { sel: '.like-button-wrapper', reason: 'سجّل دخولك لتتمكن من التفاعل مع المحتوى' },
    { sel: 'img[alt="تعليق"]',     reason: 'سجّل دخولك لتتمكن من التعليق' },
    { sel: '.follow-btn',          reason: 'سجّل دخولك لتتمكن من المتابعة' }
  ];
  /* زر النشر و"حسابي" غير مقفلين حالياً (قيد التطوير). لقفلهما لاحقاً أضف:
     { sel: '.publish-btn', reason: 'سجّل دخولك لتتمكن من النشر' },
     { sel: '.bottom-nav [aria-label="حسابي"]', reason: 'سجّل دخولك للوصول إلى حسابك' } */

  var $ = function (id) { return document.getElementById(id); };
  var panelLogin = $('auLogin'), panelLogout = $('auLogout'), subEl = $('auSub'), tipEl = $('auTip');
  var acc = $('sidebarAccountItem'), logoutSection = $('sidebarLogoutSection'), logoutItem = $('sidebarLogoutItem');
  var user = null, lastFocus = null, toastTimer = null;

  function toast(msg) {
    var t = $('lfToast'); if (!t) return;
    t.textContent = msg; t.classList.add('lf-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('lf-show'); }, 2200);
  }

  /* الدخول بـ Google لا يعمل داخل المتصفحات المدمجة (فيسبوك، إنستغرام...) */
  function inAppBrowser() {
    var ua = navigator.userAgent || '';
    return /FBAN|FBAV|FB_IAB|Instagram|Snapchat|TikTok|musical_ly|Line\/|; wv\)/i.test(ua);
  }

  /* ---------- النافذة الموحدة ---------- */
  function focusables() {
    return Array.prototype.slice.call(overlay.querySelectorAll('button')).filter(function (b) { return b.offsetParent !== null; });
  }
  function openModal(which, reason) {
    lastFocus = document.activeElement;
    panelLogin.hidden = which !== 'login';
    panelLogout.hidden = which !== 'logout';
    if (which === 'login') {
      subEl.textContent = reason || 'سجّل دخولك للاستمتاع بكل مزايا الموقع';
      tipEl.hidden = !inAppBrowser();
    }
    overlay.classList.add('au-open');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    var f = which === 'login' ? $('auGoogle') : $('auLogoutOk'); if (f) f.focus();
  }
  function closeModal() {
    overlay.classList.remove('au-open');
    overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
  }
  function closeSidebar() {
    var m = $('sidebarMenu'), c = $('sidebarCloseBtn');
    if (m && c && m.classList.contains('sidebar-open')) c.click();
  }

  overlay.addEventListener('click', function (e) { if (e.target === overlay) closeModal(); });
  Array.prototype.forEach.call(overlay.querySelectorAll('[data-au-close]'), function (b) { b.addEventListener('click', closeModal); });
  document.addEventListener('keydown', function (e) {
    if (!overlay.classList.contains('au-open')) return;
    if (e.key === 'Escape') { closeModal(); return; }
    if (e.key === 'Tab') {
      var items = focusables(); if (!items.length) return;
      var first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* ---------- الحالة ---------- */
  function validPhoto(u) { return typeof u === 'string' && /^(https:\/\/|data:image\/)/.test(u); }
  function currentPhoto() {
    var pa = window.LionProfile && window.LionProfile.getAvatar && window.LionProfile.getAvatar();
    return pa || (user && user.photo) || '';
  }

  function renderAccount() {
    var box = acc.querySelector('.sidebar-icon-box');
    var label = acc.querySelector('.sidebar-item-label');
    box.textContent = '';
    box.classList.add('au-round');
    var img = document.createElement('img');
    img.alt = '';
    img.src = (user && currentPhoto()) || DEFAULT_AVATAR;
    img.onerror = function () { img.onerror = null; img.src = DEFAULT_AVATAR; };
    box.appendChild(img);
    label.textContent = user ? 'ملفي الشخصي' : 'تسجيل دخول';
    logoutSection.hidden = !user;
  }

  function setUser(u) {
    if (u && typeof u === 'object') {
      user = { name: String(u.name || ''), photo: validPhoto(u.photo) ? u.photo : '' };
    } else {
      user = null;
    }
    renderAccount();
    if (user && overlay.classList.contains('au-open')) closeModal();
    document.dispatchEvent(new CustomEvent('lion:auth-change', { detail: user }));
  }

  /* ---------- الاعتراض: الزائر يفتح له نافذة الدخول بدل الإجراء ---------- */
  document.addEventListener('click', function (e) {
    if (user) return;
    var t = e.target;
    if (!t || !t.closest) return;
    for (var i = 0; i < GATES.length; i++) {
      var hit = t.closest(GATES[i].sel);
      if (!hit) continue;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      closeSidebar();
      var r = GATES[i].reason;
      openModal('login', typeof r === 'function' ? r(hit) : r);
      return;
    }
  }, true);

  /* ---------- زر Google ---------- */
  $('auGoogle').addEventListener('click', function () {
    document.dispatchEvent(new CustomEvent('lion:google-login'));
    if (typeof api.onGoogleLogin === 'function') api.onGoogleLogin();
    else toast('تسجيل الدخول بـ Google قيد الربط');
  });

  /* ---------- تسجيل الخروج ---------- */
  if (logoutItem) logoutItem.addEventListener('click', function () {
    closeSidebar();
    openModal('logout');
  });
  $('auLogoutOk').addEventListener('click', function () {
    document.dispatchEvent(new CustomEvent('lion:logout'));   // الباك اند: أنهِ الجلسة هنا
    setUser(null);
    closeModal();
    toast('تم تسجيل الخروج');
  });

  document.addEventListener('lion:profile-save', renderAccount);

  /* ---------- واجهة للباك اند ---------- */
  var api = window.LionAuth = {
    get user() { return user; },
    isLoggedIn: function () { return !!user; },
    setUser: setUser,
    onGoogleLogin: null,   // اربط هنا بدء الدخول بـ Google: LionAuth.onGoogleLogin = function () { ... }
    requireLogin: function (reason) {
      if (user) return true;
      closeSidebar();
      openModal('login', reason);
      return false;
    }
  };

  renderAccount();
  if (DEMO_LOGIN_PARAM && /[?&]demo-login=1(&|$)/.test(location.search)) setUser({ name: 'مستخدم تجريبي', photo: '' });
})();
