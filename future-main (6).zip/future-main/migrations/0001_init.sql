-- Liogram: المخطط الأولي. أي تعديل مستقبلي = ملف جديد (0002_xxx.sql) ولا تعدّل هذا الملف أبدًا.

CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  google_sub    TEXT NOT NULL UNIQUE,
  email         TEXT NOT NULL,
  name          TEXT NOT NULL DEFAULT '',
  avatar        TEXT NOT NULL DEFAULT '',
  role          TEXT NOT NULL DEFAULT 'user'   CHECK (role IN ('user','mod','admin')),
  status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','banned')),
  created_at    INTEGER NOT NULL,
  last_login_at INTEGER NOT NULL
);

CREATE TABLE profiles (
  user_id    TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL DEFAULT '',
  type       TEXT NOT NULL DEFAULT '',
  field      TEXT NOT NULL DEFAULT '',
  loc        TEXT NOT NULL DEFAULT '',
  bio        TEXT NOT NULL DEFAULT '',
  whatsapp   TEXT NOT NULL DEFAULT '',
  socials    TEXT NOT NULL DEFAULT '[]',
  hours_from TEXT,
  hours_to   TEXT,
  avatar     TEXT NOT NULL DEFAULT '',
  cover      TEXT NOT NULL DEFAULT '',
  cover_x    REAL NOT NULL DEFAULT 50,
  cover_y    REAL NOT NULL DEFAULT 50,
  updated_at INTEGER NOT NULL
);

CREATE TABLE sessions (
  id           TEXT PRIMARY KEY,                -- بصمة SHA-256 للرمز (الرمز نفسه لا يُخزَّن)
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL,
  expires_at   INTEGER NOT NULL,
  user_agent   TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_exp  ON sessions(expires_at);

CREATE TABLE ads (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  root        TEXT NOT NULL,
  path        TEXT NOT NULL,                    -- JSON: مسار التصنيف كما اختاره المستخدم
  path_text   TEXT NOT NULL,                    -- نفس المسار بفاصل داخلي للفلترة السريعة
  title       TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price       REAL,
  currency    TEXT NOT NULL DEFAULT '',
  images      TEXT NOT NULL DEFAULT '[]',
  status      TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','removed')),
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);
CREATE INDEX idx_ads_feed ON ads(status, created_at DESC, id DESC);
CREATE INDEX idx_ads_path ON ads(status, path_text);
CREATE INDEX idx_ads_user ON ads(user_id, created_at DESC);

CREATE TABLE follows (
  follower_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  followee_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  INTEGER NOT NULL,
  PRIMARY KEY (follower_id, followee_id)
);
CREATE INDEX idx_follows_followee ON follows(followee_id);

CREATE TABLE notifications (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type       TEXT NOT NULL,
  actor_id   TEXT REFERENCES users(id) ON DELETE CASCADE,
  read       INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_notif_user ON notifications(user_id, created_at DESC);

CREATE TABLE uploads (
  key          TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL,
  size         INTEGER NOT NULL,
  created_at   INTEGER NOT NULL
);
CREATE INDEX idx_uploads_user ON uploads(user_id);

CREATE TABLE rate_limits (
  key        TEXT PRIMARY KEY,
  window     INTEGER NOT NULL,
  count      INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
